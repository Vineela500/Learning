var name1:string ="Vineela"
//console.log("name "+name1);
var stream:string ="Computer Science";
console.log("Stream: "+stream);
/*var like:string ="I really enjoyed doing my mini project. We built a chatbot that would predict the mental health condition of a person"
console.log(like);*/