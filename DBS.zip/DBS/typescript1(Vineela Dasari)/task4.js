var str1 = "Hello my name is Vineela";
var str2 = "I like JAVA";
var str3 = str1.concat(str2);
console.log(str3);
