var str1:string ="Hello my name is Vineela ";
var str2: string ="I like JAVA";
var str3:string =str1.concat(str2);
console.log(str3);