class myClass1
{
    myData : number=30 ;
  
  //constructor() { console.log ("This is constructor..");};
  constructor(data:number){this.myData=data};
  
  returnData() : number
  { return this.myData;} 
}
var myClassObj = new myClass1;
console.log ("Class data : " + myClassObj.returnData());
