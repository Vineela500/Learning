var data: number| string;
data=20;
console.log(data);
data="data";
console.log(data);
function datatype(data:number|string):void{
    if(typeof data=="string"){
        console.log("string");
    }
    else {
        console.log("number");
    }
}
datatype("vin");
datatype(20);