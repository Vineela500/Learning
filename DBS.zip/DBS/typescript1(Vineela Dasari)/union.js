var data;
data = 20;
console.log(data);
data = "data";
console.log(data);
function datatype(data) {
    if (typeof data == "string") {
        console.log("string");
    }
    else {
        console.log("number");
    }
}
datatype("vin");
datatype(20);
