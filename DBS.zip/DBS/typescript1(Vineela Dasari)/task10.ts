function func(num1:number, num2:number): number{
    if(num1<num2){
        return num1;
    }
    return num2;
}
console.log(func(20,80));