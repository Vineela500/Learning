var myClass1 = /** @class */ (function () {
    //constructor() { console.log ("This is constructor..");};
    function myClass1(data) {
        this.myData = 30;
        this.myData = data;
    }
    ;
    myClass1.prototype.returnData = function () { return this.myData; };
    return myClass1;
}());
var myClassObj = new myClass1;
console.log("Class data : " + myClassObj.returnData());
