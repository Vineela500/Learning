var num1:number =10;
var result = num1%2==0 ? "even " : "odd";
console.log(result);