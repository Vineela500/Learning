var name1 = "Vineela";
//console.log("name "+name1);
var stream = "Computer Science";
console.log("Stream: " + stream);
/*var like:string ="I really enjoyed doing my mini project. We built a chatbot that would predict the mental health condition of a person"
console.log(like);*/ 
