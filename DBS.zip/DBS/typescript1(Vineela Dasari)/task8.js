var age = 20;
if (age >= 18) {
    console.log("Eligible for voting");
}
else {
    console.log("Not eligible");
}
