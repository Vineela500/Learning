var num1:number = -20;
var res = num1>=0 ? (num1 ==0 ? "zero":"positive") : "negative";
console.log(res);