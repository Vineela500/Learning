function func(num1, num2) {
    if (num1 > num2) {
        return num1;
    }
    return num2;
}
console.log(func(20, 80));
