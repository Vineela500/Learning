var fact = 10;
var total = 1;
for (var i = 1; i <= 10; i++) {
    total *= i;
}
console.log(total);
