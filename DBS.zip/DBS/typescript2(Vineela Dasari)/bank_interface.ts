export interface bank1{
    assign(acct_no:number,name:string,balance:number):void;
    display():void;
}