var count:number = 0;
for(var i:number=1;count<10;i++){
  if(i%2==0){
      console.log(i);
      count+=1;
  }
}