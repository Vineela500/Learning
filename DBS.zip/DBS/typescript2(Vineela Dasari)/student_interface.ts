export interface student1{
    getId():number;
    getName():string;
    getStream():string;
}