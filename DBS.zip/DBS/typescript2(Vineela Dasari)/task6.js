var emp = [101, "Rajesh", "Sales", "Manager", 200000,];
console.log("emp id: " + emp[0] + " Name: " + emp[1] + " Dept: " + emp[2] + "Desig" + emp[3] + " Salary" + emp[4]);
emp[5] = 46;
console.log("emp id: " + emp[0] + " Name: " + emp[1] + " Dept: " + emp[2] + "Desig" + emp[3] + " Salary" + emp[4] + " age" + emp[5]);
