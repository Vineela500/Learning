var fact:number = 10;
var total:number = 1;
for(var i:number=1;i<=10;i++){
    total*=i;
}
console.log(total);