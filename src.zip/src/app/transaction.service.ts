import { Injectable } from '@angular/core';
import { Transaction } from './transaction';
@Injectable({
  providedIn: 'root'
})
export class TransactionService {

  constructor() { }
  trans: Transaction[]=[
    {
      id:"20",
      date:"2019-01-16" ,
      name:"rajesh",
      medicine:"atrax",
      amount:"600"

    },
    {
      id:"40",
      date:"2019-02-16",
      name:"rajesh",
      medicine:"benadryl",
      amount:"200"

    },
    {
      id:"30",
      date:"2019-08-16" ,
      name:"anil",
      medicine:"crocin",
      amount:"200"

    },
    {
      id:"30",
      date:"2019-10-25" ,
      name:"johnny",
      medicine:"crocin",
      amount:"200"

    },
    {
      id:"60",
      date:"2018-10-23" ,
      name:"johnny",
      medicine:"aspirin",
      amount:"500"

    },
    {
      id:"86",
      date:"2017-11-25" ,
      name:"rajesh",
      medicine:"Furosemide",
      amount:"850"

    },
    {
      id:"43",
      date:"2013-11-16" ,
      name:"rajesh",
      medicine:"Indapamide",
      amount:"450"

    },
    {
      id:"89",
      date:"2014-08-24" ,
      name:"anil",
      medicine:"Methyclothiazide",
      amount:"500"

    },
    {
      id:"29",
      date:"2016-08-25" ,
      name:"anil",
      medicine:"Chlorothiazide",
      amount:"190"

    },
    {
      id:"31",
      date:"2016-05-02" ,
      name:"anil",
      medicine:"Enalapril",
      amount:"670"

    },
    {
      id:"28",
      date:"2017-04-12" ,
      name:"anil",
      medicine:"Moexipril",
      amount:"520"

    },
    {
      id:"41",
      date:"2019-04-12" ,
      name:"anil",
      medicine:"crocin",
      amount:"200"

    },
    {
      id:"41",
      date:"2019-10-12" ,
      name:"rajesh",
      medicine:"crocin",
      amount:"200"

    },
    {
      id:"41",
      date:"2019-12-12" ,
      name:"johnny",
      medicine:"crocin",
      amount:"200"

    },
    
  ]
}
