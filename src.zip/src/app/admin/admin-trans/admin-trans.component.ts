import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Transaction } from 'src/app/transaction';
import { TransactionService } from 'src/app/transaction.service';

@Component({
  selector: 'app-admin-trans',
  templateUrl: './admin-trans.component.html',
  styleUrls: ['./admin-trans.component.css']
})
export class AdminTransComponent implements OnInit {

  constructor(private trans:TransactionService) { }
  use: any[];
  id1:string="";
  name1:string="";
  date1:string="";
  medicine1:string="";
  amount1:string="";
  ngOnInit(): void {
    this.use=this.trans.trans;
  }
  
}
