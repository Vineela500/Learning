export class Transaction{
    id:string;
    date:string;
    name:string;
    medicine:string;
    amount:string;
    constructor(id:string,
        date:string,
        name:string,
        medicine:string,
        amount:string){
            this.id=id;
            this.date=date;
            this.name=name;
            this.medicine=medicine;
            this.amount=amount;

        }
}