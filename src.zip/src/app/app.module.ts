import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginService } from './login.service';
import { HttpClientModule } from '@angular/common/http';
import { CustomerComponent } from './customer/customer.component';
import { AdminComponent } from './admin/admin.component';
import { TransactionService } from './transaction.service';
import { AdminTransComponent } from './admin/admin-trans/admin-trans.component';
import { CustTransactionComponent } from './customer/cust-transaction/cust-transaction.component';
import { CustomerPurchaseComponent } from './customer/customer-purchase/customer-purchase.component';
import { CustomerTransactionComponent } from './customer/customer-purchase/customer-transaction/customer-transaction.component';
import { PurchaseService } from './purchase.service';
import { ResetComponent } from './reset/reset.component';
import { FilterPipe } from './filter.pipe';
import { SortDirective } from './admin/directive/sort.directive';


const app:Routes =[
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'reset',
    component: ResetComponent
  },
  {
    path:'home',
    component: HomeComponent
  },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  {
    path:'cust',
    component: CustomerComponent
  },
  {
    path:'admin',
    component: AdminComponent
  },
  {
    path:'admin/trans',
    component: AdminTransComponent
  },
  {
    path:'cust/trans',
    component: CustTransactionComponent
  },
  {
    path:'cust/purchase',
    component: CustomerPurchaseComponent
  },
  {
    path:'cust/purchase/trans',
    component: CustomerTransactionComponent
  },
]
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    CustomerComponent,
    AdminComponent,
    AdminTransComponent,
    CustTransactionComponent,
    CustomerPurchaseComponent,
    CustomerTransactionComponent,
    ResetComponent,
    FilterPipe,
    SortDirective,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(app),
    
  ],
  providers: [LoginService,TransactionService,PurchaseService],
  bootstrap: [AppComponent]
})
export class AppModule { }
