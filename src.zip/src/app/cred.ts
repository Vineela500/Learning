export class Cred{
    user:string;
    pass:string;
    name:string;
    type:string;
    email:string;
    constructor(user:string,pass:string,
        name:string,
        type:string,email:string){
            this.user=user;
            this.pass=pass;
            this.name=name;
            this.type=type;
            this.email=email;
        }
}