import { Component, Input, OnInit } from '@angular/core';
import { LoginService } from 'src/app/login.service';
import { Transaction } from 'src/app/transaction';
import { TransactionService } from 'src/app/transaction.service';

@Component({
  selector: 'app-cust-transaction',
  templateUrl: './cust-transaction.component.html',
  styleUrls: ['./cust-transaction.component.css']
})
export class CustTransactionComponent implements OnInit {
 
  constructor(private trans:TransactionService, private login:LoginService) { }
  user:string=this.login.user1;
  transa: any=[];
  mock: Transaction[]=[];
  ngOnInit(): void {
    this.transa=this.trans.trans;
    const user=this.login.user1;
    console.log(user);
    console.log(this.transa);
    for (let index = 0; index < this.transa.length; index++) {
      if(user==this.transa[index].name){
         const ref= new Transaction(this.transa[index].id,this.transa[index].date,this.transa[index].name,this.transa[index].medicine,this.transa[index].amount);
         this.mock.push(ref);
      }
      
    }
    console.log(this.mock[0].name);

  }

}
