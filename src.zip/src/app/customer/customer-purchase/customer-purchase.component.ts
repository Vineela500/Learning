import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/data.service';
import { PurchaseService } from 'src/app/purchase.service';

@Component({
  selector: 'app-customer-purchase',
  templateUrl: './customer-purchase.component.html',
  styleUrls: ['./customer-purchase.component.css']
})
export class CustomerPurchaseComponent implements OnInit {

  constructor(private data:PurchaseService) { }
  id:number;
  user:string;
  ngOnInit(): void {

  }
 crocin(){
   console.log("crocin")
   this.data.store("crocin","200");
 }
 atarax(){
   this.data.store("atarax","300");
 }
 moex(){
   this.data.store("moexipril","520");
 }
 adochlor(){
  this.data.store("Chlorothiazid","190");
 }
 meth(){
   this.data.store("Methyclothiazide","300");
 }
 inda(){
   this.data.store("Indapamide","290");
 }
}
