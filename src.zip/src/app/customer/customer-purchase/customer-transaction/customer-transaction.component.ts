
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/login.service';
import { PurchaseService } from 'src/app/purchase.service';
import { Transaction } from 'src/app/transaction';
import { TransactionService } from 'src/app/transaction.service';

@Component({
  selector: 'app-customer-transaction',
  templateUrl: './customer-transaction.component.html',
  styleUrls: ['./customer-transaction.component.css']
})
export class CustomerTransactionComponent implements OnInit {

  constructor(private pur: PurchaseService, private login:LoginService, private trans:TransactionService, private route:Router) { }
  id:string;
  date:string;
  name:string;
  medicine:string;
  amount:string;
  user:string = this.login.user1;
  ngOnInit(): void {
    console.log("hello hi")
    this.id=Math.floor((Math.random()+1) * 10).toString();
    let date: Date = new Date();
    this.date="2020-10-19";
    this.name=this.login.user1;
    this.medicine=this.pur.medicine;
    this.amount=this.pur.price;
    
  }
 purchase(){
   alert("Transaction Successful")
   const ref=new Transaction(this.id,this.date,this.name,this.medicine,this.amount);
   this.trans.trans.push(ref);
   console.log("hello")
   this.route.navigateByUrl("cust");
 }
}
