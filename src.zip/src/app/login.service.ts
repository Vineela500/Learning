import { useAnimation } from '@angular/animations';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';


import { Cred } from './cred';
import { DataService } from './data.service';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  status:string="fail";
  user1:string="default";
  constructor(private httpClient: HttpClient,private use:DataService) { }
 
  user: Cred[]=this.use.user;
  login(user:string,psw:string):string{
  
    console.log(this.user);
     this.user1=user;
     
             console.log(this.user.length);  
    for (let index = 0; index < this.user.length; index++) {
      
      if(user==this.user[index].user){
        console.log("inside if"+psw+" "+this.user[index].pass);
       
        if(psw==this.user[index].pass){
          console.log("inside 2 if")
          this.status=this.user[index].type;
          
          console.log(this.status);
        }
      }
      
    }
   
 
              
      console.log("hello");       
      console.log(this.status);
      return this.status; 
  
}
user2:string;
store(name:string){
this.user2=name;
}
}
