import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Cred } from '../cred';
import { DataService } from '../data.service';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-reset',
  templateUrl: './reset.component.html',
  styleUrls: ['./reset.component.css']
})
export class ResetComponent implements OnInit {

  constructor(private data: DataService, private name:LoginService, private route:Router) { }
  user: Cred[]=this.data.user;
  uname:string =this.name.user2;
  ngOnInit(): void {
  }
  reset(form: NgForm){
    const psw=form.value.psw;
    for (let index = 0; index < this.user.length; index++) {
      if(this.user[index].user==this.uname){
        this.user[index].pass=psw;
      }
      
    }
    alert("Password reset successful. Redirecting to login page");
    this.route.navigateByUrl("home");
  }

}
