import { Injectable } from '@angular/core';
import { Cred } from './cred';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor() { }
  user: Cred[]=[
    {
      user:"admin",
      pass:"admin",
       name: "Alchemy",
       type:"admin",
       email:"vineelareddy3@gmail.com"
  },
  {
      user:"rajesh",
      pass:"123",
      name:"Rajesh",
      type:"cust",
      email:"vineelareddy3@gmail.com"
  },
  {
      user:"anil",
      pass:"012",
      name:"Anil",
      type:"cust",
      email:"vineelareddy3@gmail.com"
  },
  {
      user:"johnny",
      pass:"123",
      name:"Johnny",
      type:"cust",
      email:"vineelareddy3@gmail.com"
  }
  
  ]
}
