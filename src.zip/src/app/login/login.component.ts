import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Cred } from '../cred';
import { DataService } from '../data.service';

import { LoginService } from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent{

  constructor(private login:LoginService, private data: DataService, private router: Router) { }
  user: Cred[]=this.data.user;
  ngOnInit(): void {

  }
  name:string=" ";
  pass:string;
  status:string;
  type:string;
  login1:boolean =true;
  email:string;
  mock: Cred[]=[];
  toggle(){
    this.login1=false;
  }
 addEmp(form: NgForm){
   this.name=form.value.uname;
   this.pass=form.value.psw;
   console.log(this.name,this.pass);
    this.status=this.login.login(this.name,this.pass);
    if(this.status=="cust"){
     alert("Login success");
     this.router.navigateByUrl("cust");
     
    }
    else if(this.status=="admin"){
      alert("Login");
      this.router.navigateByUrl("admin");
    }
    else{
      alert("Login Failed");
    }
 }
 user2:string;
 forgot1(form: NgForm){
    const name=form.value.name;
    const email=form.value.email;
    console.log(this.user);
    let flag=0;
    console.log(name+" "+email);
    for (let index = 0; index < this.user.length; index++) {
      console.log(this.user[index].name+" "+this.user[index].email);
      if(name==this.user[index].user){
        if(email==this.user[index].email){
          console.log("entered inside 2 if");
         flag=1;
        }
      }
      
    }
    if(flag==0){
      alert("Either the username or email is wrong");
      this.login1 = true;
    }
    else{
      alert("Reset your password");
      this.router.navigateByUrl("reset");
    }
    
   this.login.store(name);
 }
}
