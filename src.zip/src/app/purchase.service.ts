import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PurchaseService {

  constructor() { }
  medicine:string;
  price:string;
  store(medicine:string,price:string){
    this.medicine=medicine;
    this.price=price;
  }
}
